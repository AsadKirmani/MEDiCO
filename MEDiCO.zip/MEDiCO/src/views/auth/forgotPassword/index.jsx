import React from "react";
import ForgotPasswordDefault from "./components/ForgotPassword";

function forgotPassword() {

  return (
        <ForgotPasswordDefault />
  );
}

export default forgotPassword;