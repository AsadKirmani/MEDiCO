export const tableColumnsSales = [
    {
      Header: "Name",
      accessor: "name",
    },
    {
      Header: "Product",
      accessor: "product",
    },
    {
      Header: "Date",
      accessor: "date",
    },
    {
      Header: "Status",
      accessor: "status",
    },
    {
      Header: "Price",
      accessor: "price",
    },
  ];
  