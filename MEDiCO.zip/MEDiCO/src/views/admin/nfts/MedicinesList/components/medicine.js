import React from 'react';

export default function Medicines(){

    return (
        <div>
            data
        </div>
    )
}