export const columnsDataUsersOverview = [
  {
    Header: "MEDICINE NAME",
    accessor: "name",
  },
  {
    Header: "MEDICINE ID",
    accessor: "medID",
  },
  {
    Header: "GROUP NAME",
    accessor: "groupname",
  },
  {
    Header: "STOCK IN QTY",
    accessor: "stock",
  },
  {
    Header: "ACTIONS",
    accessor: "actions",
  },
];
