import React from "react";
import { Link } from 'react-router-dom';

// Chakra imports
import {
  Box,
  Button,
  Icon,
  Text,
  useColorModeValue,
  SimpleGrid,
} from "@chakra-ui/react";

import { MdOutlineMedicalServices, MdOutlineWarningAmber, MdOutlineKeyboardDoubleArrowRight } from 'react-icons/md';

// Custom components
import Card from "components/card/Card.js";
import IconBox from "components/icons/IconBox";

export default function Inventory() {

  // Chakra Color Mode
  const brandColor = useColorModeValue("brand.500", "white");
  return (
    <Box pt={{ base: "180px", md: "80px", xl: "80px" }}>
       <SimpleGrid
        columns={{ base: 1, md: 2, lg: 4, "2xl": 4 }}
        gap='20px'
        mb='20px'>
      <Card style={{border:'1px solid #03a9f5'}}>
            <Box align='center'>
            <IconBox                                      
            w='56px'
            h='56px'
            icon={
              <Icon w='48px' h='48px' as={MdOutlineMedicalServices} color='#03a9f5' />
            }
            />
            <Text align="center" fontSize='2xl' fontWeight='extrabold' mt='10px'>298</Text>
            <Text align="center" fontSize='md' fontWeight='thin' mt='5px'>Medicines Available</Text>
            <Link to='/admin/inventory/list-of-medicines/'>
            <Button isFullWidth color={brandColor} variant="outline" rightIcon={<MdOutlineKeyboardDoubleArrowRight />} mt='10px'>
              View Full List
            </Button>
            </Link>
            </Box>
          </Card>
          <Card style={{border:'1px solid #01a768'}}>
            <Box align='center'>
            <IconBox                                      
            w='56px'
            h='56px'
            icon={
              <Icon w='48px' h='48px' as={MdOutlineMedicalServices} color='#01a768' />
            }
            />
            <Text align="center" fontSize='2xl' fontWeight='extrabold' mt='10px'>02</Text>
            <Text align="center" fontSize='md' fontWeight='thin' mt='5px'>Medicine Groups</Text>
            <Link to='/admin/inventory/medicine-groups/'>
            <Button isFullWidth color={brandColor} variant="outline" rightIcon={<MdOutlineKeyboardDoubleArrowRight />} mt='10px'>
              View Groups
            </Button>
            </Link>
            </Box>
          </Card>
          <Card style={{border:'1px solid #f0483e'}}>
            <Box align='center'>
            <IconBox                                      
            w='56px'
            h='56px'
            icon={
              <Icon w='48px' h='48px' as={MdOutlineWarningAmber} color='#f0483e' />
            }
            />
            <Text align="center" fontSize='2xl' fontWeight='extrabold' mt='10px'>01</Text>
            <Text align="center" fontSize='md' fontWeight='thin' mt='5px'>Medicine Shortage</Text>
            <Button isFullWidth color={brandColor} variant="outline" rightIcon={<MdOutlineKeyboardDoubleArrowRight />} mt='10px'>
              Resolve Now
            </Button>
            </Box>
          </Card>
          </SimpleGrid>
    </Box>
  );
}