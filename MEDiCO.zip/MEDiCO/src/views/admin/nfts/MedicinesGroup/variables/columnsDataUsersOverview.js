export const columnsDataUsersOverview = [
  {
    Header: "GROUP NAME",
    accessor: "name",
  },
  {
    Header: "NO OF MEDICINES",
    accessor: "medicines",
  },
  {
    Header: "ACTIONS",
    accessor: "actions",
  },
];
