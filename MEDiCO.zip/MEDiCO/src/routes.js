import React from 'react';
import { Icon } from '@chakra-ui/react';
import { MdOutlineInventory2, MdOutlineTableChart, MdLock } from 'react-icons/md';
import { BiHomeAlt2, BiUser } from 'react-icons/bi'

// Admin Imports
import DashboardsDefault from 'views/admin/dashboards/default';
import DashboardsRTLDefault from 'views/admin/dashboards/rtl';

// Inventory Imports
import MedicinesList from 'views/admin/nfts//MedicinesList';
import EcommerceNewProduct from 'views/admin/main/ecommerce/newProduct';
import ProductSettings from 'views/admin/main/ecommerce/settingsProduct';
import ProductPage from 'views/admin/main/ecommerce/pageProduct';

// Reports Imports
import SalesReport from 'views/admin/reports/salesReport';
import PaymentsReport from 'views/admin/reports/paymentsReport';

// Account Reports
import ProfileSettings from 'views/admin/main/profile/settings';

// Auth Imports
import SignIn from 'views/auth/signIn';
import SignUp from 'views/auth/signUp';
import ForgotPassword from 'views/auth/forgotPassword';

const routes = [
	// --- Dashboards ---
	{
		name: 'Home',
		path: '/dashboards',
		icon: <Icon as={BiHomeAlt2} width='20px' height='20px' color='inherit' />,
		collapse: true,
		items: [
			{
				name: 'Dashboard',
				layout: '/admin',
				path: '/dashboards/default',
				component: DashboardsDefault
			},
			{
				name: 'RTL',
				layout: '/rtl',
				path: '/dashboards/rtl',
				component: DashboardsRTLDefault
			},
		]
	},
	// --- Inventory ---
	{
		name: 'Inventory',
		path: '/inventory',
		icon: <Icon as={MdOutlineInventory2} width='20px' height='20px' color='inherit' />,
		secondary: true,
		collapse: true,
		items: [
			{
				name: 'List of Medicines',
				path: '/inventory/all-medicines',
				layout: '/admin',
				component: MedicinesList
			},
			{
				name: 'Medicine',
				path: '/inventory/medicine',
				collapse: true,
				items: [
					{
						name: 'Add Medicine',
						layout: '/admin',
						path: '/inventory/medicine/new',
						exact: false,
						component: EcommerceNewProduct
					}
				]
			},
					{
						path: '/inventory/all-medicines/:medId/edit',
						component: ProductSettings
					},
					{
						
						path:'/inventory/all-medicines/:medId',
						component: ProductPage
					}
				]
			
	},
	// --- Reports ---
	{
		name: 'Reports',
		path: '/reports',
		icon: <Icon as={MdOutlineTableChart} width='20px' height='20px' color='inherit' />,
		collapse: true,
		isAdmin: true,
		items: [
			{
						name: 'Sales Report',
						layout: '/admin',
						path: '/reports/sales-reports',
						component: SalesReport,
						exact: false
					},
					{
						name: 'Payments Report',
						layout: '/admin',
						path: '/reports/payments-reports',
						component: PaymentsReport,
						exact: false
					},
		]	
	},
	// ---  Account ---
	{
		name: 'Account',
		path: '/account',
		icon: <Icon as={BiUser} width='20px' height='20px' color='inherit' />,
		layout: '/admin',
		component: ProfileSettings
	},
	//Auth Pages
	{
		name: 'Authentication',
		path: '/auth',
		icon: <Icon as={MdLock} width='20px' height='20px' color='inherit' />,
		collapse: true,
		items: [
			{
				name: 'Logged in!',
				path:'/'
			}
			,{
				
				path: '/sign-in',
				layout: '/auth',
				component: SignIn
			},
			{
				path: '/sign-up',
				layout: '/auth',
				component: SignUp
			},
			{
				path: '/forgot-password',
				layout: '/auth',
				component: ForgotPassword
			}
		]
	}
];

export default routes;
