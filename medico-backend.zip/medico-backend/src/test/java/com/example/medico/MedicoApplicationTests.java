package com.example.medico;

import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class MedicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
